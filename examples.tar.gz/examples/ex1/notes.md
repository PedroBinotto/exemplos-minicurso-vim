# Exemplo 1.1: MOVENDO O CURSOR/MODOS/ALTERAÇÕES SIMPLES

Demonstrações:

- Navegando no modo NORMAL.: `hjkl`, `gg`, `G`, motions;
- Navegando entre os modos do editor;
- Alterações simples de texto no modo INSERT/VISUAL;
- Edição com delimitadores `{}`, `()`, "<>", "''";
- Interação com comandos simples no modo COMMAND.: `:w`, `:q`, `:make`, `:!`...;
